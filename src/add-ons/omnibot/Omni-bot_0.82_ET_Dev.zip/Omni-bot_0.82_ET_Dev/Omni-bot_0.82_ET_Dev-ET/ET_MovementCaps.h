
#ifndef __ET_MOVEMENTCAPS_H__
#define __ET_MOVEMENTCAPS_H__

#include "MovementCaps.h"

namespace Movement
{
	enum
	{
		MOVE_DISGUISE = MOVE_MAX,

		ET_MOVE_MAX,
	};
};

#endif
