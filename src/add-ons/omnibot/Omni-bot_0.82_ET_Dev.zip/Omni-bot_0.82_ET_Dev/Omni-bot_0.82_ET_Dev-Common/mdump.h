
#ifndef _MDUMP_H_
#define _MDUMP_H_

namespace MiniDumper
{
	void Init(const char *_appname);
	void Shutdown();
}

#endif
