
#ifndef __MOVEMENTCAPS_H__
#define __MOVEMENTCAPS_H__

namespace Movement
{
	enum
	{
		MOVE_WALK,
		MOVE_JUMP,

		MOVE_MAX,
	};
};

#endif
