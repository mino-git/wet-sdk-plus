
#ifndef __REVISION_H__
#define __REVISION_H__

namespace Revision
{
	String Number();
	String Date();
};

#endif
