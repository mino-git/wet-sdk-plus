////////////////////////////////////////////////////////////////////////////////
// 
// $LastChangedBy$
// $LastChangedDate$
// $LastChangedRevision$
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __GM_NAMELIST_H__
#define __GM_NAMELIST_H__

class gmMachine;
#include "gmThread.h"

extern gmType GM_NAMESLIST;

void gmBindNamesListLib(gmMachine * a_machine);

#endif
